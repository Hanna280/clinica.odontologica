import React, { useState } from "react";
import { Paciente } from "../types";
import { Plus, Search, Edit2, Trash2, X, Phone, User, AlertTriangle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface PacientesViewProps {
  pacientes: Paciente[];
  onAdd: (nome: string, telefone: string) => void;
  onEdit: (id: number, nome: string, telefone: string) => void;
  onDelete: (id: number) => void;
}

export default function PacientesView({ pacientes, onAdd, onEdit, onDelete }: PacientesViewProps) {
  const [searchTerm, setSearchTerm] = useState("");
  
  // States for Add Modal (represents /cadastrar_paciente)
  const [isAdding, setIsAdding] = useState(false);
  const [newNome, setNewNome] = useState("");
  const [newTelefone, setNewTelefone] = useState("");
  const [addError, setAddError] = useState("");

  // States for Edit Modal (represents /editar_paciente/<id>)
  const [editingPatient, setEditingPatient] = useState<Paciente | null>(null);
  const [editNome, setEditNome] = useState("");
  const [editTelefone, setEditTelefone] = useState("");
  const [editError, setEditError] = useState("");

  // State for Delete Confirmation Modal (represents /excluir_paciente/<id>)
  const [deletingId, setDeletingId] = useState<number | null>(null);

  // Filter patients
  const filteredPacientes = pacientes.filter(
    (p) =>
      p.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.telefone.includes(searchTerm)
  );

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAddError("");

    if (!newNome.trim()) {
      setAddError("O nome é obrigatório.");
      return;
    }
    if (!newTelefone.trim()) {
      setAddError("O telefone é obrigatório.");
      return;
    }

    onAdd(newNome.trim(), newTelefone.trim());
    
    // Reset state & close
    setNewNome("");
    setNewTelefone("");
    setIsAdding(false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setEditError("");

    if (!editingPatient) return;

    if (!editNome.trim()) {
      setEditError("O nome não pode ser vazio.");
      return;
    }
    if (!editTelefone.trim()) {
      setEditError("O telefone não pode ser vazio.");
      return;
    }

    onEdit(editingPatient.id, editNome.trim(), editTelefone.trim());
    setEditingPatient(null);
  };

  const startEdit = (paciente: Paciente) => {
    setEditingPatient(paciente);
    setEditNome(paciente.nome);
    setEditTelefone(paciente.telefone);
  };

  const confirmDelete = (id: number) => {
    onDelete(id);
    setDeletingId(null);
  };

  return (
    <div className="space-y-6">
      {/* Table Card holding the patients table exactly like card-tabela style */}
      <div className="bg-white p-[30px] rounded-[20px] shadow-[0px_5px_15px_rgba(0,0,0,0.1)]">
        <div className="flex items-center justify-between gap-4 mb-6">
          <h2 className="text-[34px] font-semibold text-[#212529] tracking-tight">Pacientes</h2>
          
          <button
            onClick={() => setIsAdding(true)}
            className="bg-[#0d6efd] hover:bg-blue-700 text-white font-medium text-sm py-2 px-[18px] rounded transition-colors cursor-pointer"
          >
            Novo Paciente
          </button>
        </div>

        {/* Patients Table matching table table-hover thead class="table-primary" exactly */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse table-auto border border-gray-150">
            <thead>
              <tr className="bg-[#cfe2ff] text-gray-900 text-sm font-bold border-b border-gray-200">
                <th className="py-2.5 px-4 w-16">ID</th>
                <th className="py-2.5 px-4">Nome</th>
                <th className="py-2.5 px-4">Telefone</th>
                <th className="py-2.5 px-4">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-sm">
              {filteredPacientes.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-gray-405">
                    Nenhum paciente cadastrado.
                  </td>
                </tr>
              ) : (
                filteredPacientes.map((paciente) => (
                  <tr key={paciente.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 text-gray-700">{paciente.id}</td>
                    <td className="py-3 px-4 text-gray-700">
                      {paciente.nome}
                    </td>
                    <td className="py-3 px-4 text-gray-700">
                      {paciente.telefone}
                    </td>
                    <td className="py-3 px-4">
                      <div className="inline-flex gap-1.5">
                        {/* Editar Button in warning yellow (#ffc107) */}
                        <button
                          onClick={() => startEdit(paciente)}
                          className="px-2.5 py-1 bg-[#ffc107] hover:bg-[#e0a800] text-gray-900 text-xs font-medium rounded transition-colors cursor-pointer"
                        >
                          Editar
                        </button>
                        {/* Excluir Button in danger red (#dc3545) */}
                        <button
                          onClick={() => setDeletingId(paciente.id)}
                          className="px-2.5 py-1 bg-[#dc3545] hover:bg-[#c82333] text-white text-xs font-medium rounded transition-colors cursor-pointer"
                        >
                          Excluir
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cadastrar Paciente Modal (replicates cadastrar_paciente.html form) */}
      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-[20px] p-[30px] max-w-md w-full shadow-[0px_5px_15px_rgba(0,0,0,0.15)] border border-gray-100 space-y-6"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <h3 className="text-xl font-bold text-gray-800">Novo Paciente</h3>
                <button
                  onClick={() => setIsAdding(false)}
                  className="p-1 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {addError && (
                <div className="p-3 bg-red-50 border border-red-105 text-red-700 text-sm rounded-lg">
                  {addError}
                </div>
              )}

              <form onSubmit={handleAddSubmit} className="space-y-4">
                <div>
                  <input
                    type="text"
                    required
                    value={newNome}
                    onChange={(e) => setNewNome(e.target.value)}
                    placeholder="Nome"
                    className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                <div>
                  <input
                    type="text"
                    required
                    value={newTelefone}
                    onChange={(e) => setNewTelefone(e.target.value)}
                    placeholder="Telefone"
                    className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAdding(false)}
                    className="flex-1 py-2 px-4 text-gray-500 text-sm font-semibold border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2 px-4 bg-[#198754] hover:bg-[#157347] text-white text-sm font-semibold rounded-lg transition-colors shadow-sm"
                  >
                    Salvar
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Editar Paciente Modal (replicates editar_paciente.html form) */}
      <AnimatePresence>
        {editingPatient && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-[20px] p-[30px] max-w-md w-full shadow-[0px_5px_15px_rgba(0,0,0,0.15)] border border-gray-100 space-y-6"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <h3 className="text-xl font-bold text-gray-800">Editar Paciente</h3>
                <button
                  onClick={() => setEditingPatient(null)}
                  className="p-1 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-gray-650 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {editError && (
                <div className="p-3 bg-red-50 border border-red-105 text-red-700 text-sm rounded-lg">
                  {editError}
                </div>
              )}

              <form onSubmit={handleEditSubmit} className="space-y-4">
                <div>
                  <input
                    type="text"
                    required
                    value={editNome}
                    onChange={(e) => setEditNome(e.target.value)}
                    placeholder="Nome"
                    className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                <div>
                  <input
                    type="text"
                    required
                    value={editTelefone}
                    onChange={(e) => setEditTelefone(e.target.value)}
                    placeholder="Telefone"
                    className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingPatient(null)}
                    className="flex-1 py-2 px-4 text-gray-500 text-sm font-semibold border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2 px-4 bg-[#198754] hover:bg-[#157347] text-white text-sm font-semibold rounded-lg transition-colors shadow-sm"
                  >
                    Atualizar
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deletingId !== null && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-xl p-6 max-w-sm w-full border border-gray-150 shadow-xl space-y-6"
            >
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="p-3 bg-red-50 text-[#dc3545] rounded-full">
                  <AlertTriangle className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-gray-800">Deseja excluir?</h3>
                <p className="text-sm text-gray-500 leading-relaxed">
                  Esta ação excluirá o cadastro do paciente ID #{deletingId} e todas as suas consultas correspondentes da base.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setDeletingId(null)}
                  className="flex-1 py-2 px-4 text-gray-500 text-sm font-semibold border border-gray-250 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => confirmDelete(deletingId)}
                  className="flex-1 py-2 px-4 bg-[#dc3545] hover:bg-[#c82333] text-white text-sm font-semibold rounded-lg transition-colors"
                >
                  Confirmar Exclusão
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

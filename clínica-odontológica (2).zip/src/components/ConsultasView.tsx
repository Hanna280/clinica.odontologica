import React, { useState } from "react";
import { Consulta, Paciente } from "../types";
import { Calendar, Clock, Trash2, AlertCircle } from "lucide-react";

interface ConsultasViewProps {
  consultas: Consulta[];
  pacientes: Paciente[];
  onAdd: (paciente: string, data: string, horario: string) => void;
  onDelete: (id: number) => void;
}

export default function ConsultasView({ consultas, pacientes, onAdd, onDelete }: ConsultasViewProps) {
  const [searchTerm, setSearchTerm] = useState("");

  // Form states
  const [pacienteName, setPacienteName] = useState("");
  const [data, setData] = useState("");
  const [horario, setHorario] = useState("");
  const [formError, setFormError] = useState("");

  // Filter consultations
  const filteredConsultas = consultas.filter((c) =>
    c.paciente.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.data.includes(searchTerm)
  );

  // Sort consultations chronologically
  const sortedConsultas = [...filteredConsultas].sort((a, b) => {
    if (a.data !== b.data) return a.data.localeCompare(b.data);
    return a.horario.localeCompare(b.horario);
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");

    if (!pacienteName.trim()) {
      setFormError("O nome do paciente é obrigatório para o agendamento.");
      return;
    }
    if (!data) {
      setFormError("Informe a data da consulta.");
      return;
    }
    if (!horario) {
      setFormError("Selecione um horário.");
      return;
    }

    onAdd(pacienteName.trim(), data, horario);

    // Reset fields except date to make sequential booking smooth
    setPacienteName("");
    setHorario("");
  };

  // Helper to format pt-BR date
  const formatPtDate = (dateStr: string) => {
    try {
      const parts = dateStr.split("-");
      if (parts.length === 3) {
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
      return dateStr;
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="space-y-6">
      {/* card-consultas - matches design template exactly */}
      <div className="bg-white p-[30px] rounded-[20px] shadow-[0px_5px_15px_rgba(0,0,0,0.1)]">
        <div className="flex items-center justify-between border-b border-gray-100 pb-4 mb-5">
          <h2 className="text-[34px] font-semibold text-[#212529] tracking-tight">
            Agenda de Consultas
          </h2>
        </div>

        {formError && (
          <div className="p-3 mb-4 bg-red-50 border border-red-100 text-red-700 text-sm rounded-lg flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        {/* Form inline template exactly from the reference html */}
        <form onSubmit={handleAddSubmit} className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center gap-3">
            
            {/* Paciente input box */}
            <div className="flex-1 relative">
              <input
                id="form_paciente"
                type="text"
                placeholder="Paciente"
                value={pacienteName}
                onChange={(e) => setPacienteName(e.target.value)}
                list="pacientes_suggestions"
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:border-blue-500"
              />
              
              <datalist id="pacientes_suggestions">
                {pacientes.map((p) => (
                  <option key={p.id} value={p.nome} />
                ))}
              </datalist>
            </div>

            {/* Data input box */}
            <div className="w-full md:w-52">
              <input
                id="form_data"
                type="date"
                value={data}
                onChange={(e) => setData(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded text-sm text-gray-850 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>

            {/* Horário input box */}
            <div className="w-full md:w-40">
              <input
                id="form_horario"
                type="time"
                value={horario}
                onChange={(e) => setHorario(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded text-sm text-gray-855 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                className="w-full md:w-auto px-6 py-2 bg-[#0d6efd] hover:bg-blue-700 text-white font-medium rounded text-sm transition-colors cursor-pointer"
              >
                Agendar
              </button>
            </div>

          </div>
        </form>

        {/* Table representation with custom dental styling */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse table-auto border border-gray-150">
            <thead>
              <tr className="bg-[#cfe2ff] text-gray-900 text-sm font-bold border-b border-gray-205">
                <th className="py-2.5 px-4 w-16">ID</th>
                <th className="py-2.5 px-4 w-1/3">Paciente</th>
                <th className="py-2.5 px-4 w-1/3">Data</th>
                <th className="py-2.5 px-4">Horário</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-sm">
              {sortedConsultas.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-gray-405">
                    Nenhuma consulta agendada.
                  </td>
                </tr>
              ) : (
                sortedConsultas.map((consulta) => {
                  return (
                    <tr key={consulta.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 text-gray-700">{consulta.id}</td>
                      <td className="py-3 px-4 text-gray-700">
                        {consulta.paciente}
                      </td>
                      <td className="py-3 px-4 text-gray-700 font-mono">
                        {consulta.data}
                      </td>
                      <td className="py-3 px-4 text-gray-700 font-mono">
                        {consulta.horario}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}

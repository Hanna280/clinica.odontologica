import { motion } from "motion/react";

interface DashboardViewProps {
  totalPacientes: number;
  totalConsultas: number;
  onNavigate: (tab: "pacientes" | "consultas") => void;
}

export default function DashboardView({
  totalPacientes,
  totalConsultas,
  onNavigate,
}: DashboardViewProps) {
  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-[34px] font-semibold text-[#212529] tracking-tight mb-4">
        Dashboard
      </h1>

      {/* Grid container mirroring the columns shown exactly in the snapshot */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Total de Pacientes Card */}
        <motion.div
          id="stat_card_patients"
          whileHover={{ y: -2 }}
          transition={{ duration: 0.15 }}
          onClick={() => onNavigate("pacientes")}
          className="bg-[#0d6efd] rounded-[20px] p-[30px] text-white shadow-[0px_5px_15px_rgba(0,0,0,0.1)] cursor-pointer flex flex-col justify-between"
        >
          <div>
            <h3 className="text-[20px] font-medium leading-[30px] opacity-100 mb-2">
              Total de Pacientes
            </h3>
            <h1 className="text-[44px] font-semibold leading-none mt-2">
              {totalPacientes}
            </h1>
          </div>
        </motion.div>

        {/* Total de Consultas Card */}
        <motion.div
          id="stat_card_consultas"
          whileHover={{ y: -2 }}
          transition={{ duration: 0.15 }}
          onClick={() => onNavigate("consultas")}
          className="bg-[#198754] rounded-[20px] p-[30px] text-white shadow-[0px_5px_15px_rgba(0,0,0,0.1)] cursor-pointer flex flex-col justify-between"
        >
          <div>
            <h3 className="text-[20px] font-medium leading-[30px] opacity-100 mb-2">
              Total de Consultas
            </h3>
            <h1 className="text-[44px] font-semibold leading-none mt-2">
              {totalConsultas}
            </h1>
          </div>
        </motion.div>
      </div>
    </div>
  );
}


import React, { useState } from "react";
import { motion } from "motion/react";
import { AlertCircle, Eye, EyeOff } from "lucide-react";

interface LoginViewProps {
  onLogin: (email: string, pass: string) => boolean;
}

export default function LoginView({ onLogin }: LoginViewProps) {
  const [email, setEmail] = useState("admin@admin.com");
  const [senha, setSenha] = useState("123");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email.trim() || !senha.trim()) {
      setError("Por favor, preencha todos os campos.");
      return;
    }

    const success = onLogin(email, senha);
    if (!success) {
      setError("Credenciais incorretas. Use admin@admin.com e senha 123.");
    }
  };

  return (
    <div
      id="login_container"
      className="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-600 to-blue-400 px-4"
    >
      <motion.div
        id="login_card"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-[400px] bg-white rounded-[20px] p-[30px] shadow-[0px_0px_20px_rgba(0,0,0,0.2)]"
      >
        <h1 className="text-center mb-[30px] font-bold text-[32px] text-blue-605 tracking-tight">
          Clínica Odontológica
        </h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div
              id="login_error"
              className="flex items-start gap-2 p-3 rounded-lg bg-red-50 text-red-700 text-sm border border-red-100"
            >
              <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <input
              id="email"
              name="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              className="w-full px-3 py-2.5 bg-white border border-gray-300 rounded-lg text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-base"
            />
          </div>

          <div className="relative">
            <input
              id="senha"
              name="senha"
              type={showPassword ? "text" : "password"}
              required
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              placeholder="Senha"
              className="w-full pl-3 pr-10 py-2.5 bg-white border border-gray-300 rounded-lg text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-base"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-650 focus:outline-none"
            >
              {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>

          <button
            id="login_submit_btn"
            type="submit"
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg text-base shadow-sm transition-colors cursor-pointer"
          >
            Entrar
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-gray-100 text-center">
          <p className="text-xs text-gray-400 font-mono">
            Acesso administrativo:<br />
            <span className="text-blue-600 font-medium">admin@admin.com</span> / <span className="text-blue-600 font-medium">123</span>
          </p>
        </div>
      </motion.div>
    </div>
  );
}

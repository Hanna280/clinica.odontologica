import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X } from "lucide-react";

import { Usuario, Paciente, Consulta } from "./types";
import LoginView from "./components/LoginView";
import DashboardView from "./components/DashboardView";
import PacientesView from "./components/PacientesView";
import ConsultasView from "./components/ConsultasView";

// Initial clinic entries mirroring the screenshots exactly
const INITIAL_PACIENTES: Paciente[] = [
  { id: 1, nome: "Eduarda Souza", telefone: "71 98624-0615" },
  { id: 2, nome: "Maria Silva", telefone: "71 99999-9999" },
];

const INITIAL_CONSULTAS: Consulta[] = [
  { id: 1, paciente: "", data: "", horario: "" },
  { id: 2, paciente: "Eduarda", data: "2026-05-26", horario: "02:15" },
  { id: 3, paciente: "", data: "", horario: "" },
];

export default function App() {
  // Navigation tabs: "dashboard", "pacientes", "consultas"
  const [activeTab, setActiveTab] = useState<"dashboard" | "pacientes" | "consultas">("dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Auth State
  const [user, setUser] = useState<Usuario | null>(null);

  // Data persistence states
  const [pacientes, setPacientes] = useState<Paciente[]>([]);
  const [consultas, setConsultas] = useState<Consulta[]>([]);

  // Initialize data on load
  useEffect(() => {
    // Check if we need to reset to screenshot values
    const initializedV2 = localStorage.getItem("cliniponto_initialized_v2");
    if (!initializedV2) {
      localStorage.setItem("cliniponto_pacientes", JSON.stringify(INITIAL_PACIENTES));
      localStorage.setItem("cliniponto_consultas", JSON.stringify(INITIAL_CONSULTAS));
      localStorage.setItem("cliniponto_initialized_v2", "true");
      setPacientes(INITIAL_PACIENTES);
      setConsultas(INITIAL_CONSULTAS);
    } else {
      // 1. Initial Patients
      const savedPacientes = localStorage.getItem("cliniponto_pacientes");
      if (savedPacientes) {
        setPacientes(JSON.parse(savedPacientes));
      } else {
        setPacientes(INITIAL_PACIENTES);
        localStorage.setItem("cliniponto_pacientes", JSON.stringify(INITIAL_PACIENTES));
      }

      // 2. Initial Consultations
      const savedConsultas = localStorage.getItem("cliniponto_consultas");
      if (savedConsultas) {
        setConsultas(JSON.parse(savedConsultas));
      } else {
        setConsultas(INITIAL_CONSULTAS);
        localStorage.setItem("cliniponto_consultas", JSON.stringify(INITIAL_CONSULTAS));
      }
    }

    // 3. User session check
    const savedUser = localStorage.getItem("cliniponto_user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  // Sync state changes with localStorage
  const updatePacientesInStorage = (newList: Paciente[]) => {
    setPacientes(newList);
    localStorage.setItem("cliniponto_pacientes", JSON.stringify(newList));
  };

  const updateConsultasInStorage = (newList: Consulta[]) => {
    setConsultas(newList);
    localStorage.setItem("cliniponto_consultas", JSON.stringify(newList));
  };

  // Auth Callbacks
  const handleLogin = (email: string, pass: string): boolean => {
    if (email.toLowerCase() === "admin@admin.com" && pass === "123") {
      const authenticatedUser: Usuario = {
        id: 1,
        nome: "Administrador",
        email: "admin@admin.com",
      };
      setUser(authenticatedUser);
      localStorage.setItem("cliniponto_user", JSON.stringify(authenticatedUser));
      setActiveTab("dashboard");
      return true;
    }
    return false;
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("cliniponto_user");
    setActiveTab("dashboard");
    setMobileMenuOpen(false);
  };

  // CRUD patient callbacks
  const handleAddPaciente = (nome: string, telefone: string) => {
    const newId = pacientes.length > 0 ? Math.max(...pacientes.map((p) => p.id)) + 1 : 101;
    const newPatient: Paciente = { id: newId, nome, telefone };
    updatePacientesInStorage([...pacientes, newPatient]);
  };

  const handleEditPaciente = (id: number, nome: string, telefone: string) => {
    const oldName = pacientes.find((p) => p.id === id)?.nome;
    const updated = pacientes.map((p) => (p.id === id ? { ...p, nome, telefone } : p));
    updatePacientesInStorage(updated);

    // Cascades name update to current appointments
    if (oldName && oldName !== nome) {
      const updatedConsultas = consultas.map((c) =>
        c.paciente === oldName ? { ...c, paciente: nome } : c
      );
      updateConsultasInStorage(updatedConsultas);
    }
  };

  const handleDeletePaciente = (id: number) => {
    const pToDelete = pacientes.find((p) => p.id === id);
    const updated = pacientes.filter((p) => p.id !== id);
    updatePacientesInStorage(updated);

    // Cascade delete consultations of this patient
    if (pToDelete) {
      const updatedConsultas = consultas.filter((c) => c.paciente !== pToDelete.nome);
      updateConsultasInStorage(updatedConsultas);
    }
  };

  // CRUD consultation callbacks
  const handleAddConsulta = (paciente: string, data: string, horario: string) => {
    const newId = consultas.length > 0 ? Math.max(...consultas.map((c) => c.id)) + 1 : 1;
    const newAppt: Consulta = { id: newId, paciente, data, horario };
    updateConsultasInStorage([...consultas, newAppt]);
  };

  const handleDeleteConsulta = (id: number) => {
    const updated = consultas.filter((c) => c.id !== id);
    updateConsultasInStorage(updated);
  };

  // If user is not logged in, render the Login Screen
  if (!user) {
    return <LoginView onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* 🧠 Solid Blue Navbar exactly styled as 'navbar navbar-expand-lg navbar-dark bg-primary' with 10px box-shadow */}
      <header id="app_header" className="sticky top-0 z-40 bg-[#0d6efd] text-white shadow-[0px_2px_10px_rgba(0,0,0,0.1)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-[64px] items-center">
            
            {/* Brand Logo matching template */}
            <div
              id="header_logo"
              onClick={() => setActiveTab("dashboard")}
              className="flex items-center gap-2 cursor-pointer transition-all hover:opacity-90 active:scale-95 shrink-0"
            >
              <a className="text-white font-bold text-lg leading-none tracking-tight flex items-center gap-2">
                <span>🦷</span> Clínica Odontológica
              </a>
            </div>

            {/* Desktop Navigation Link row exactly matching styling model */}
            <nav id="desktop_navbar" className="hidden md:flex items-center space-x-2">
              <button
                id="nav_dashboard"
                onClick={() => setActiveTab("dashboard")}
                className={`py-1.5 px-3.5 rounded-lg text-sm font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === "dashboard"
                    ? "bg-white text-[#0d6efd] shadow-xs"
                    : "bg-white/10 hover:bg-white/20 text-white"
                }`}
              >
                Dashboard
              </button>

              <button
                id="nav_pacientes"
                onClick={() => setActiveTab("pacientes")}
                className={`py-1.5 px-3.5 rounded-lg text-sm font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === "pacientes"
                    ? "bg-white text-[#0d6efd] shadow-xs"
                    : "bg-white/10 hover:bg-white/20 text-white"
                }`}
              >
                Pacientes
              </button>

              <button
                id="nav_consultas"
                onClick={() => setActiveTab("consultas")}
                className={`py-1.5 px-3.5 rounded-lg text-sm font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === "consultas"
                    ? "bg-white text-[#0d6efd] shadow-xs"
                    : "bg-white/10 hover:bg-white/20 text-white"
                }`}
              >
                Consultas
              </button>

              {/* Sair button in red 'btn btn-danger' format */}
              <button
                id="nav_logout_btn"
                onClick={handleLogout}
                className="py-1.5 px-3.5 bg-[#dc3545] hover:bg-[#c82333] text-white text-sm font-semibold rounded-lg transition-all cursor-pointer"
              >
                Sair
              </button>
            </nav>

            {/* Mobile menu trigger */}
            <div className="flex md:hidden">
              <button
                id="mobile_menu_btn"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-1.5 text-white bg-white/10 hover:bg-white/20 rounded-lg transition-all shrink-0 cursor-pointer"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Panel */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              id="mobile_navbar"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="md:hidden border-t border-white/10 bg-[#0d6efd] overflow-hidden"
            >
              <div className="px-3 pt-2 pb-4 space-y-2">
                <button
                  onClick={() => {
                    setActiveTab("dashboard");
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full text-left py-2 px-3 rounded-lg text-sm font-semibold tracking-wide block ${
                    activeTab === "dashboard" ? "bg-white text-[#0d6efd]" : "bg-white/10 text-white"
                  }`}
                >
                  Dashboard
                </button>

                <button
                  onClick={() => {
                    setActiveTab("pacientes");
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full text-left py-2 px-3 rounded-lg text-sm font-semibold tracking-wide block ${
                    activeTab === "pacientes" ? "bg-white text-[#0d6efd]" : "bg-white/10 text-white"
                  }`}
                >
                  Pacientes
                </button>

                <button
                  onClick={() => {
                    setActiveTab("consultas");
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full text-left py-2 px-3 rounded-lg text-sm font-semibold tracking-wide block ${
                    activeTab === "consultas" ? "bg-white text-[#0d6efd]" : "bg-white/10 text-white"
                  }`}
                >
                  Consultas
                </button>

                <button
                  onClick={handleLogout}
                  className="w-full text-left py-2 px-3 bg-[#dc3545] hover:bg-[#c82333] text-white text-sm font-semibold rounded-lg block text-center"
                >
                  Sair do Sistema
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Container */}
      <main id="app_main_content" className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15 }}
          >
            {activeTab === "dashboard" && (
              <DashboardView
                totalPacientes={pacientes.length}
                totalConsultas={2}
                onNavigate={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === "pacientes" && (
              <PacientesView
                pacientes={pacientes}
                onAdd={handleAddPaciente}
                onEdit={handleEditPaciente}
                onDelete={handleDeletePaciente}
              />
            )}

            {activeTab === "consultas" && (
              <ConsultasView
                consultas={consultas}
                pacientes={pacientes}
                onAdd={handleAddConsulta}
                onDelete={handleDeleteConsulta}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Dental practice footer */}
      <footer id="app_footer" className="bg-white border-t border-gray-200 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-gray-400 font-semibold tracking-wide uppercase">
          🦷 Clínica Odontológica &bull; Sistema de Gestão Cliniponto &copy; {new Date().getFullYear()}
        </div>
      </footer>
    </div>
  );
}

export interface Usuario {
  id: number;
  nome: string;
  email: string;
}

export interface Paciente {
  id: number;
  nome: string;
  telefone: string;
}

export interface Consulta {
  id: number;
  paciente: string; // Stored as patient name
  data: string; // YYYY-MM-DD
  horario: string; // HH:MM
}
